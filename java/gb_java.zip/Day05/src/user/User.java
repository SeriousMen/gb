package user;
//먼저 User라는 클래스를 만든다. 
public class User {

	public String id;
	public String pw;
	
	public User() {;} //마커
	
}
