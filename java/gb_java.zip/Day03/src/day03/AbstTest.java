package day03;

public class AbstTest {
	public static void main(String[] args) {
		//추상클래스를 구현을 하지않은채로 메모리에 할당하려고했을때
		
//		Shape s = new Shape() 
		
	}
}
