package day03;

// Rect에서 final로 상속을 막았기 떄문에 상속할 수 없다. extends Rect (x)
public class KIm {

}
