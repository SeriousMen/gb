package day03;

public class Access2 {
	public static void main(String[] args) {
		Access1 a1 =new Access1();
//		a1. //private 사용할 수 없음
	}
}
