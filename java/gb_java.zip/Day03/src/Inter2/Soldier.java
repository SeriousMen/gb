package Inter2;

public interface Soldier {
	//군인이라면 가질 공통 사항
	int arm = 2;	
	int leg = 2;
	
	void eat();
	void sleep();
	void salute();
	void work();
	
}
