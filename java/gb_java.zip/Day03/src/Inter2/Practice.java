package Inter2;

public interface Practice extends Soldier{ //쓰지말것 나중에 문제
	
@Override
default void salute() {//default로선언됨
	// TODO Auto-generated method stub
	
}
@Override
	default void work() {
		// TODO Auto-generated method stub
		
	}

}
