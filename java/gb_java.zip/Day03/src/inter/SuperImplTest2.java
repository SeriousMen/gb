package inter;

public class SuperImplTest2 {
	
	public void printName() {
		System.out.println("한동석 부모클래스");
	}
}
