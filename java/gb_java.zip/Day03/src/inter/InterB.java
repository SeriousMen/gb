package inter;

public interface InterB {

	default void printName() {
		System.out.println("한동석 InterB");
	}
}
