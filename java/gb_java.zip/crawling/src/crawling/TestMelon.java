package crawling;

public class TestMelon {
	public static void main(String[] args) {
		Melon melon = new Melon();
		
		melon.operate();
	}
	
	
	

}


