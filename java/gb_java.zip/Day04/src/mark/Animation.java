package mark;
// ; 만 쓴 인터페이스(마커 인터페이스) : 일부러 비워둔 것이다. 라고 표현한 것 
public interface Animation {;}
