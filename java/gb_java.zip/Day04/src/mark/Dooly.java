package mark;

public class Dooly extends Video implements Animation{

	@Override
	public String toString() {
		
		return "둘리";
	}
}
