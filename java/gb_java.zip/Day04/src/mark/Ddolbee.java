package mark;

public class Ddolbee extends Video implements Animation{

@Override
	public String toString() {
		return "똘비" ;
	}	
}
