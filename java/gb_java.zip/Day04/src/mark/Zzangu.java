package mark;

public class Zzangu extends Video implements Animation{

	@Override
	public String toString() {
		
		return "짱구";
	}
}
