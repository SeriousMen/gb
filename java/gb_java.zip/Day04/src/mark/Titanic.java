package mark;

public class Titanic extends Video {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "타이타닉";
	}
}
