package mark;

public class Video {

}
